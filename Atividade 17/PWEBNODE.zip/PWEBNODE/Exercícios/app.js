let app = require("./app/config/server");
//carregando o módulo do servidor

let texto = require("./modulo1"); // importando o módulo1

let rotaHome = require("./app/routes/home"); // só está definindo a rota, não está executando a função

//app.get("/", function (req, res) {
//  res.send("<html><body>Site da FATEC Sorocaba</body></html>");
//});

rotaHome(app); // executando a função rotaHome, passando o app como parâmetro

let rotaAdicionarUsuario = require("./app/routes/adicionar_usuario");
rotaAdicionarUsuario(app);

let rotaHistoria = require("./app/routes/historia");
rotaHistoria(app);

let rotaCursos = require("./app/routes/cursos");
rotaCursos(app); //está executando

let rotaProfessores = require("./app/routes/professores");
rotaProfessores(app); //está executando

app.listen(3000, function () {
  console.log("Olá, Servidor com express foi carregado com sucesso!");
});
